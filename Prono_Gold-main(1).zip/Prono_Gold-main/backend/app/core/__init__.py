"""
Core module - Configuration, Security, Database
"""

from .config import settings

__all__ = ["settings"]
