"""
PronoTurf Backend API
Application de pronostics hippiques intelligents
"""

__version__ = "0.1.0"
__author__ = "LeProfDeTechno27"
